create view pg_statio_all_tables
            (relid, schemaname, relname, heap_blks_read, heap_blks_hit, idx_blks_read, idx_blks_hit, toast_blks_read,
             toast_blks_hit, tidx_blks_read, tidx_blks_hit)
as
SELECT c.oid                                                                                        AS relid,
       n.nspname                                                                                    AS schemaname,
       c.relname,
       pg_stat_get_blocks_fetched(c.oid) - pg_stat_get_blocks_hit(c.oid)                            AS heap_blks_read,
       pg_stat_get_blocks_hit(c.oid)                                                                AS heap_blks_hit,
       sum(pg_stat_get_blocks_fetched(i.indexrelid) - pg_stat_get_blocks_hit(i.indexrelid))::bigint AS idx_blks_read,
       sum(pg_stat_get_blocks_hit(i.indexrelid))::bigint                                            AS idx_blks_hit,
       pg_stat_get_blocks_fetched(t.oid) - pg_stat_get_blocks_hit(t.oid)                            AS toast_blks_read,
       pg_stat_get_blocks_hit(t.oid)                                                                AS toast_blks_hit,
       sum(pg_stat_get_blocks_fetched(x.indexrelid) - pg_stat_get_blocks_hit(x.indexrelid))::bigint AS tidx_blks_read,
       sum(pg_stat_get_blocks_hit(x.indexrelid))::bigint                                            AS tidx_blks_hit
FROM pg_class c
         LEFT JOIN pg_index i ON c.oid = i.indrelid
         LEFT JOIN pg_class t ON c.reltoastrelid = t.oid
         LEFT JOIN pg_index x ON t.oid = x.indrelid
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE c.relkind = ANY (ARRAY ['r'::"char", 't'::"char", 'm'::"char"])
GROUP BY c.oid, n.nspname, c.relname, t.oid, x.indrelid;

alter table pg_statio_all_tables
    owner to postgres;

grant select on pg_statio_all_tables to public;

