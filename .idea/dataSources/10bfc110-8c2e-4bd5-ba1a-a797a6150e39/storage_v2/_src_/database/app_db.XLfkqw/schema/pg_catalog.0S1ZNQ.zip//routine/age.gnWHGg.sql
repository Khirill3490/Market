create function age(timestamp without time zone) returns interval
    stable
    strict
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.age(cast(current_date as timestamp without time zone), $1)$$;

comment on function age(timestamp, unknown) is 'date difference from today preserving months and years';

alter function age(timestamp, unknown) owner to postgres;

