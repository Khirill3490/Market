create function rpad(text, integer) returns text
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$select pg_catalog.rpad($1, $2, ' ')$$;

comment on function rpad(text, integer, unknown) is 'right-pad string to length';

alter function rpad(text, integer, unknown) owner to postgres;

