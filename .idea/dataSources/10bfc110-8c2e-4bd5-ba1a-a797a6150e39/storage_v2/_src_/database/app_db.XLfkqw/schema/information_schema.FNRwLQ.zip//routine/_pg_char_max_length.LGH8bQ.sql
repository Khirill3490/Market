create function _pg_char_max_length(typid oid, typmod integer) returns integer
    immutable
    strict
    parallel safe
    language sql
as
$$SELECT
  CASE WHEN $2 = -1 /* default typmod */
       THEN null
       WHEN $1 IN (1042, 1043) /* char, varchar */
       THEN $2 - 4
       WHEN $1 IN (1560, 1562) /* bit, varbit */
       THEN $2
       ELSE null
  END$$;

alter function _pg_char_max_length(oid, integer) owner to postgres;

