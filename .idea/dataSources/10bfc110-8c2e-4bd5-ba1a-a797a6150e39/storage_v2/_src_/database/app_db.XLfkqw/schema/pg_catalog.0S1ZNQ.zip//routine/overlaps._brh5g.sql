create function "overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, interval) returns boolean
    stable
    parallel safe
    cost 1
    language sql
as
$$select ($1, $2) overlaps ($3, ($3 + $4))$$;

comment on function "overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, interval) is 'intervals overlap?';

alter function "overlaps"(timestamp with time zone, timestamp with time zone, timestamp with time zone, interval) owner to postgres;

